% 
% function decryptedImage = UnIndexScramble (Index, encryptedImage)
%  
%   Inputs
%   encryptedImage: the encrypted image
%    Index: random index for random permutation

%   Outputs
%   decryptedImage: the decrypted image.


function decryptedImage = UnIndexScramble (Index, encryptedImage)
  [high, width] = size(encryptedImage);
  reshape_encrypted_image_to_vec = reshape(encryptedImage, high * width, 1);       
  vectorized_image = zeros(high * width, 1);            
 
  for k=1: 1: high * width
     vectorized_image (Index(k)) =  reshape_encrypted_image_to_vec(k);
  end
 
  decryptedImage = reshape(vectorized_image, high, width); 
end