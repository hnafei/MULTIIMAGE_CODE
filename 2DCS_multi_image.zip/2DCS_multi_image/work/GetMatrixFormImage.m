function matirxImage = GetMatrixFormImage(Imagelinear,t)
  if(mod(length(Imagelinear),t) ~= 0)
     error('the length is invalid')
  end
matirxImage = reshape(Imagelinear,[],t);
end