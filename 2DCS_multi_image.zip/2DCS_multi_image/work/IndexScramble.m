% 
% function encrypted_image = IndexScramble (Index, image)
%   
%   Inputs
%   image: the image which is required to be encrypted.
%   Index: random index for random permutation

%   Outputs
%   encrypted_image: the encrypted image.


function encryptedImage = IndexScramble(Index, image)
  [high, width] = size(image);
  reshape_image_to_vec = reshape(image, high * width, 1); 
  enc_vectorized_image = zeros(high * width, 1);      %���ܺ�ͼ��
 
  for k=1: 1: high * width
     enc_vectorized_image (k) =  reshape_image_to_vec(Index(k));
  end
  encryptedImage = reshape(enc_vectorized_image, high, width); % vectorized_image to matrix image
end